SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [Proc_CMS_PageUrlPath_GenerateUrlPaths]
	@StartingNodeID INT = NULL,
	@SiteID INT,
	@CultureCodes Type_CMS_StringTable READONLY,
	@LastModified DATETIME,
	@UseCulturePrefix BIT,
	@DefaultCultureCode NVARCHAR(50),
	@HidePrefixForDefaultCulture BIT
AS

BEGIN

	DECLARE @PageTypes TABLE(
		[ID] INT NOT NULL, 
		[HasUrl] BIT NOT NULL)

	INSERT INTO @PageTypes ([ID], [HasUrl])
		SELECT 
			[ClassID], 
			[ClassHasURL] 
		FROM [CMS_Class] 
		WHERE [ClassID] IN (SELECT [ClassID] FROM [CMS_ClassSite] WHERE [SiteID] = @SiteID)
	
	IF OBJECT_ID(N'tempdb..#PreparedPaths') IS NOT NULL
	BEGIN
		DROP TABLE #PreparedPaths
	END

	CREATE TABLE #PreparedPaths (
		[ID] INT IDENTITY(1,1),
		[CultureCode] NVARCHAR(50) COLLATE DATABASE_DEFAULT NOT NULL, 
		[NodeID] INT NOT NULL, 
		[NodeGUID] UNIQUEIDENTIFIER NOT NULL, 
		[UrlPath] NVARCHAR(2000) COLLATE DATABASE_DEFAULT NOT NULL, 
		[NodeSiteID] INT NOT NULL,
		[IsRootPath] BIT NOT NULL,
		[NodeAliasPath] NVARCHAR(450) COLLATE DATABASE_DEFAULT NOT NULL,
		[NodeLevel] INT NOT NULL,
		[PathHash] NVARCHAR(64) COLLATE DATABASE_DEFAULT NOT NULL
	)
	
	DECLARE @PrefixPath NVARCHAR(2000) = ''

	-- Builds parent URL path prefix from node aliases. 
	-- In the prefix participate only node aliases of pages having URL
	IF @StartingNodeID IS NOT NULL
	BEGIN
		;WITH ParentPaths AS (
			SELECT       
				[NodeID], 
				[NodeParentID],
				[NodeSiteID],
				[NodeAliasPath],
				CAST('' AS NVARCHAR(2000)) AS ParentPath		-- Current path does not participate in prefix
			FROM [CMS_Tree]
			WHERE
				[NodeID] = @StartingNodeID

			UNION ALL

			SELECT 
				[T].[NodeID], 
				[T].[NodeParentID],
				[T].[NodeSiteID],
				[T].[NodeAliasPath],
				CAST(CASE HasUrl 
					 WHEN 1 THEN CASE [P].[ParentPath] WHEN '' THEN [T].[NodeAlias] ELSE [T].[NodeAlias] + '/' + [P].[ParentPath] END
					 ELSE [P].[ParentPath] END AS NVARCHAR(2000)) 
					 AS ParentPath
			FROM 
				[CMS_Tree] AS [T] 
					INNER JOIN ParentPaths [P] ON [T].[NodeID] = [P].[NodeParentID]
					INNER JOIN @PageTypes ON [T].[NodeClassID] = [ID]
		)
		SELECT TOP 1 @PrefixPath = [ParentPath] FROM ParentPaths
		WHERE [NodeParentID] IS NULL
	END

	-- Use temporary table with optimized index for building the paths
	IF OBJECT_ID(N'tempdb..#Nodes') IS NOT NULL
	BEGIN
		DROP TABLE #Nodes
	END

	CREATE TABLE #Nodes (
		[NodeID] INT NOT NULL, 
		[NodeGUID] UNIQUEIDENTIFIER NOT NULL, 
		[NodeParentID] INT NULL, 
		[NodeSiteID] INT NOT NULL, 
		[NodeAlias] NVARCHAR(50) COLLATE DATABASE_DEFAULT NOT NULL, 
		[NodeAliasPath] NVARCHAR(450) COLLATE DATABASE_DEFAULT NOT NULL,
		[NodeLevel] INT NOT NULL,
		[HasUrl] BIT NOT NULL
	)

	INSERT INTO #Nodes ([NodeID], [NodeGUID], [NodeParentID], [NodeSiteID], [NodeAlias], [NodeAliasPath], [NodeLevel], [HasUrl]) 
	SELECT [NodeID], [NodeGUID], [NodeParentID], [NodeSiteID], [NodeAlias], [NodeAliasPath], [NodeLevel], [P].[HasUrl]
	FROM [CMS_Tree] INNER JOIN @PageTypes as [P] ON [NodeClassID] = [ID]

	CREATE NONCLUSTERED INDEX [IX_Nodes_NodeParentID] ON #Nodes ([NodeParentID])
	INCLUDE ([NodeID], [NodeGUID], [NodeSiteID], [NodeAlias], [NodeAliasPath], [NodeLevel], [HasUrl])

	-- Build culture paths for all descendants having URL
	;WITH paths AS (
		SELECT       
			[NodeID],
			[NodeGUID],
			CAST(CASE HasUrl 
			     WHEN 1 THEN CASE @PrefixPath WHEN '' THEN [NodeAlias] ELSE @PrefixPath + '/' + [NodeAlias] END
				 ELSE @PrefixPath END AS NVARCHAR(2000)) 
				 AS Suffix,
			[NodeParentID],
			[NodeSiteID],
			[HasUrl],
			[HasUrl] AS IsRootPath,
			[NodeAliasPath],
			[NodeLevel]
		FROM       
			#Nodes
		WHERE
			(@StartingNodeID IS NULL AND [NodeParentID] IS NULL AND [NodeSiteID] = @SiteID)
			OR (@StartingNodeID IS NOT NULL AND [NodeID] = @StartingNodeID)

		UNION ALL

		SELECT 
			[T].[NodeID],
			[T].[NodeGUID],
			CAST(CASE [T].[HasUrl] 
				 WHEN 1 THEN CASE [P].[Suffix] WHEN '' THEN [T].[NodeAlias] ELSE [P].[Suffix] + '/' + [T].[NodeAlias] END
				 ELSE [P].[Suffix] END AS NVARCHAR(2000)) 
				 AS Suffix,
			[T].[NodeParentID],
			[T].[NodeSiteID],
			[T].[HasUrl],
			CAST(CASE WHEN [T].[HasUrl] = 1 AND [P].[Suffix] = '' THEN 1 ELSE 0 END AS BIT) AS IsRootPath,
			[T].[NodeAliasPath],
			[T].[NodeLevel]
		FROM 
			#Nodes AS [T] INNER JOIN paths [P] ON [P].[NodeID] = [T].[NodeParentID]
	)
	INSERT INTO #PreparedPaths ([CultureCode] , [NodeID], [NodeGUID], [UrlPath], [NodeSiteID], [IsRootPath], [NodeAliasPath], [NodeLevel], [PathHash])
		SELECT
			[CultureCode], 
			[NodeID],
			[NodeGUID],
			CASE @UseCulturePrefix 
			WHEN 1 THEN 
				CASE WHEN [CultureCode] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
				THEN [Suffix] 
				ELSE [CultureCode] + '/' + [Suffix] END 
			ELSE [Suffix] END AS UrlPath, 
			[NodeSiteID],
			[IsRootPath],
			[NodeAliasPath],
			[NodeLevel],
			CASE @UseCulturePrefix 
			WHEN 1 THEN 
				CASE WHEN [CultureCode] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
				THEN CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([Suffix])), 2) 
				ELSE CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([CultureCode] + '/' + [Suffix] )), 2) END 
			ELSE CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([Suffix] )), 2) END AS [PathHash]
		FROM
		(
			SELECT [NodeID], [NodeGUID], [Suffix], [NodeSiteID], [C].[Value] as [CultureCode], [IsRootPath], [NodeAliasPath], [NodeLevel]  
			FROM paths CROSS JOIN @CultureCodes AS C WHERE [HasUrl] = 1
		) AS S

	-- Index allows quickly to find collision paths inside the table with prepared data
	CREATE NONCLUSTERED INDEX [IX_PreparedPaths_PathHash_CultureCode] ON #PreparedPaths (
		[PathHash] ASC,
		[CultureCode] ASC
	)

    BEGIN TRANSACTION
		BEGIN TRY
			
			IF ((SELECT COUNT(*)
				FROM #PreparedPaths
				GROUP BY [PathHash], [CultureCode]
				HAVING COUNT(*) > 1) > 0
			)
				THROW 50001, 'Collision found', 1

			INSERT INTO [CMS_PageUrlPath]([PageUrlPathGUID], [PageUrlPathCulture], [PageUrlPathNodeID], [PageUrlPathUrlPath], [PageUrlPathUrlPathHash], [PageUrlPathSiteID], [PageUrlPathLastModified])
				SELECT 
					NEWID(),
					[CultureCode],
					[NodeID],
					[UrlPath],
					[PathHash],
					[NodeSiteID],
					@LastModified
				FROM #PreparedPaths
		END TRY
		BEGIN CATCH
			IF XACT_STATE() = 1
			BEGIN
			
				DECLARE @CollidingPathGroups TABLE (
					[CultureCode] NVARCHAR(50) NOT NULL, 
					[PathHash] NVARCHAR(64) NOT NULL
				)

				-- Table for paths that are in a collision with other paths in the prepared data
				DECLARE @CollidingPaths TABLE (
					[CultureCode] NVARCHAR(50) NOT NULL, 
					[NodeGUID] UNIQUEIDENTIFIER NOT NULL, 
					[UrlPath] NVARCHAR(2000) NOT NULL, 
					[NodeAliasPath] NVARCHAR(450) NOT NULL,
					[NodeLevel] INT NOT NULL
				)
								
				DECLARE @CollidingUrlPath NVARCHAR(2000)
				DECLARE @CollidingCultureCode NVARCHAR(50)
				DECLARE @CollidingNodeGUID uniqueidentifier
				DECLARE @CollidingNodeAliasPath NVARCHAR(450)

				WHILE (1 = 1)
				BEGIN	
					INSERT INTO @CollidingPathGroups([PathHash], [CultureCode])
					SELECT [PathHash], [CultureCode]
						FROM #PreparedPaths
						GROUP BY [PathHash], [CultureCode]
						HAVING COUNT(*) > 1
			
					INSERT INTO @CollidingPaths([UrlPath], [CultureCode], [NodeGUID], [NodeAliasPath], [NodeLevel])
					SELECT [P].[UrlPath], [P].[CultureCode], [P].[NodeGUID], [P].[NodeAliasPath], [P].[NodeLevel]
						FROM #PreparedPaths [P]
						INNER JOIN @CollidingPathGroups [C] ON [P].[PathHash] = [C].[PathHash] AND [P].[CultureCode] = [C].[CultureCode]

					IF ((SELECT COUNT([UrlPath]) FROM @CollidingPaths) = 0)	
						BREAK;
					
					-- Order colliding items by NodeLevel to ensure that parent paths will be processed first
					SELECT TOP (1) @CollidingUrlPath = [UrlPath], @CollidingCultureCode = [CultureCode], @CollidingNodeGUID = [NodeGUID], @CollidingNodeAliasPath = [NodeAliasPath]
					FROM @CollidingPaths
					ORDER BY [NodeLevel], [NodeAliasPath]

					DECLARE @nonColisionUrlPath NVARCHAR(2000)
					SET @nonColisionUrlPath = @CollidingUrlPath + '-' + LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', LOWER(@CollidingUrlPath + @CollidingCultureCode + CONVERT(NVARCHAR(36), @CollidingNodeGUID))), 2)) 
					
					UPDATE #PreparedPaths						  
					SET [UrlPath] = @nonColisionUrlPath + SUBSTRING(UrlPath, LEN(@CollidingUrlPath) + 1, LEN([UrlPath])),
						[PathHash] = CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(@nonColisionUrlPath + SUBSTRING(UrlPath, LEN(@CollidingUrlPath) + 1, LEN([UrlPath])))), 2)
					WHERE ([NodeAliasPath] = @CollidingNodeAliasPath OR [NodeAliasPath] LIKE @CollidingNodeAliasPath + '/%') AND [CultureCode] = @CollidingCultureCode

					DELETE FROM @CollidingPathGroups
					DELETE FROM @CollidingPaths
				END

				DECLARE @ParentsWithUrl TABLE(
					[CultureCode] NVARCHAR(50),
					[UrlPath] NVARCHAR(2000),
					[UrlPathWithHash] NVARCHAR(2000),
					[NodeAliasPath] NVARCHAR(450) NOT NULL
				)
				INSERT INTO @ParentsWithUrl ([CultureCode], [UrlPath], [UrlPathWithHash], [NodeAliasPath])
				SELECT 
					[CultureCode],
					[UrlPath],
					CASE WHEN 
						EXISTS (
							SELECT TOP 1 [PageUrlPathID] FROM [CMS_PageUrlPath] WHERE ([PageUrlPathUrlPath] = [UrlPath] OR [PageUrlPathUrlPath] LIKE [UrlPath] + '/%') AND [PageUrlPathCulture] = [CultureCode] AND [PageUrlPathSiteID] = @SiteID 
							UNION
							SELECT TOP 1 [AlternativeUrlID] FROM [CMS_AlternativeUrl] WHERE ([AlternativeUrlUrl] = [UrlPath] OR [AlternativeUrlUrl] LIKE [UrlPath] + '/%') AND [AlternativeUrlSiteID] = @SiteID
						)
						THEN [UrlPath] + '-' + LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', LOWER([UrlPath] + [CultureCode] + CONVERT(NVARCHAR(36), [NodeGUID]))), 2)) 
						ELSE [UrlPath] 
					END,
					[NodeAliasPath]
				FROM #PreparedPaths [PreparedPath]
				WHERE [IsRootPath] = 1
				
				INSERT INTO [CMS_PageUrlPath]([PageUrlPathGUID], [PageUrlPathCulture], [PageUrlPathNodeID], [PageUrlPathUrlPath], [PageUrlPathUrlPathHash], [PageUrlPathSiteID], [PageUrlPathLastModified])
					SELECT 
						NEWID(),
						[CultureCode],
						[NodeID],
						[UrlPathWithHash],
						CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([UrlPathWithHash])), 2),	-- recompute hash since the UrlPath may be changed because of collisions 
						[NodeSiteID],
						@LastModified
					FROM
					(
						SELECT 
							[PreparedPath].[CultureCode],
							[PreparedPath].[NodeID],
							[Parent].[UrlPathWithHash] + SUBSTRING([PreparedPath].[UrlPath] , LEN([Parent].[UrlPath])  + 1, LEN([PreparedPath].[UrlPath]) - LEN([Parent].[UrlPath])) AS UrlPathWithHash,
							[PreparedPath].[NodeSiteID]
						FROM #PreparedPaths [PreparedPath]
						INNER JOIN @ParentsWithUrl [Parent] 
							ON ([PreparedPath].[UrlPath] = [Parent].[UrlPath] OR [PreparedPath].[UrlPath] LIKE [Parent].[UrlPath] + '/%')
							AND [PreparedPath].[CultureCode] = [Parent].[CultureCode]
					) AS S
			END
			ELSE
			BEGIN
				ROLLBACK TRANSACTION	
			END
		END CATCH	
	COMMIT TRANSACTION
END
GO
