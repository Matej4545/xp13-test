SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_PageUrlPath](
	[PageUrlPathID] [int] IDENTITY(1,1) NOT NULL,
	[PageUrlPathGUID] [uniqueidentifier] NOT NULL,
	[PageUrlPathCulture] [nvarchar](50) NOT NULL,
	[PageUrlPathNodeID] [int] NOT NULL,
	[PageUrlPathUrlPath] [nvarchar](2000) NOT NULL,
	[PageUrlPathUrlPathHash] [nvarchar](64) NOT NULL,
	[PageUrlPathSiteID] [int] NOT NULL,
	[PageUrlPathLastModified] [datetime2](7) NOT NULL,
 CONSTRAINT [PK_CMS_PageUrlPath] PRIMARY KEY CLUSTERED 
(
	[PageUrlPathID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageUrlPath_PageUrlPathNodeID] ON [dbo].[CMS_PageUrlPath]
(
	[PageUrlPathNodeID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
CREATE NONCLUSTERED INDEX [IX_CMS_PageUrlPath_PageUrlPathSiteID] ON [dbo].[CMS_PageUrlPath]
(
	[PageUrlPathSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_CMS_PageUrlPath_PageUrlPathUrlPathHash_PageUrlPathCulture_PageUrlPathSiteID] ON [dbo].[CMS_PageUrlPath]
(
	[PageUrlPathUrlPathHash] ASC,
	[PageUrlPathCulture] ASC,
	[PageUrlPathSiteID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageUrlPath_PageUrlPathGUID]  DEFAULT ('00000000-0000-0000-0000-000000000000') FOR [PageUrlPathGUID]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageUrlPath_PageUrlPathCulture]  DEFAULT (N'') FOR [PageUrlPathCulture]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageUrlPath_PageUrlPathNodeID]  DEFAULT ((0)) FOR [PageUrlPathNodeID]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageUrlPath_PageUrlPathUrlPath]  DEFAULT (N'') FOR [PageUrlPathUrlPath]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageUrlPath_PageUrlPathUrlPathHash]  DEFAULT (N'') FOR [PageUrlPathUrlPathHash]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageUrlPath_PageUrlPathSiteID]  DEFAULT ((0)) FOR [PageUrlPathSiteID]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] ADD  CONSTRAINT [DEFAULT_CMS_PageUrlPath_PageUrlPathLastModified]  DEFAULT ('1/1/0001 12:00:00 AM') FOR [PageUrlPathLastModified]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageUrlPath_PageUrlPathNodeID_CMS_Tree] FOREIGN KEY([PageUrlPathNodeID])
REFERENCES [dbo].[CMS_Tree] ([NodeID])
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] CHECK CONSTRAINT [FK_CMS_PageUrlPath_PageUrlPathNodeID_CMS_Tree]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath]  WITH CHECK ADD  CONSTRAINT [FK_CMS_PageUrlPath_PageUrlPathSiteID_CMS_Site] FOREIGN KEY([PageUrlPathSiteID])
REFERENCES [dbo].[CMS_Site] ([SiteID])
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] CHECK CONSTRAINT [FK_CMS_PageUrlPath_PageUrlPathSiteID_CMS_Site]
GO
ALTER TABLE [dbo].[CMS_PageUrlPath]  WITH CHECK ADD  CONSTRAINT [CHECK_CMS_PageUrlPath_UniquePath] CHECK  (([dbo].[Func_CMS_Routing_NumberOfCollidingAlternativeUrls]([PageUrlPathUrlPath],[PageUrlPathSiteID])=(0)))
GO
ALTER TABLE [dbo].[CMS_PageUrlPath] CHECK CONSTRAINT [CHECK_CMS_PageUrlPath_UniquePath]
GO
