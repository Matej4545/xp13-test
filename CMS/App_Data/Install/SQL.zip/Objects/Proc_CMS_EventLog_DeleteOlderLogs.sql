SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [dbo].[Proc_CMS_EventLog_DeleteOlderLogs]
	@SiteId int,
	@LogMaxSize int,
	@MaxToDelete int,
	@DeleteEventsOfNonexistingSites bit
AS
BEGIN
	IF @SiteId > 0 
	BEGIN
		;WITH SiteEventsRowNumber AS (
			SELECT TOP (@MaxToDelete+@LogMaxSize)
				ROW_NUMBER() OVER(ORDER BY EventID DESC) RowNumber
			FROM CMS_EventLog
			WHERE SiteID = @SiteId
		)
		DELETE
		FROM SiteEventsRowNumber
		WHERE RowNumber > @LogMaxSize

		SELECT COUNT(EventID) AS RemainEventsCount
		FROM CMS_EventLog
		WHERE SiteID = @SiteId
	END
	ELSE
	BEGIN
		;WITH GlobalEventsRowNumber AS (
			SELECT TOP (@MaxToDelete+@LogMaxSize)
				ROW_NUMBER() OVER(ORDER BY EventID DESC) RowNumber
			FROM CMS_EventLog
			WHERE SiteID IS NULL
		)
		DELETE
		FROM GlobalEventsRowNumber
		WHERE RowNumber > @LogMaxSize
		
		SELECT COUNT(EventID) AS RemainEventsCount
		FROM CMS_EventLog
		WHERE SiteID IS NULL
	END

	IF @DeleteEventsOfNonexistingSites = 1
	BEGIN
		DELETE E
		FROM CMS_EventLog E
		LEFT JOIN CMS_Site S
			ON S.SiteID = E.SiteID
		WHERE E.SiteID IS NOT NULL
			AND S.SiteID IS NULL
	END
END
GO
