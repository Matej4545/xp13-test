SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Reporting_ReportTable](
	[TableID] [int] IDENTITY(1,1) NOT NULL,
	[TableName] [nvarchar](100) NOT NULL,
	[TableDisplayName] [nvarchar](450) NOT NULL,
	[TableQuery] [nvarchar](max) NOT NULL,
	[TableQueryIsStoredProcedure] [bit] NOT NULL,
	[TableReportID] [int] NOT NULL,
	[TableSettings] [nvarchar](max) NULL,
	[TableGUID] [uniqueidentifier] NOT NULL,
	[TableLastModified] [datetime2](7) NOT NULL,
	[TableConnectionString] [nvarchar](100) NULL,
 CONSTRAINT [PK_Reporting_ReportTable] PRIMARY KEY CLUSTERED 
(
	[TableID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
CREATE NONCLUSTERED INDEX [IX_Reporting_ReportTable_TableReportID] ON [dbo].[Reporting_ReportTable]
(
	[TableReportID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
SET ANSI_PADDING ON
GO
CREATE UNIQUE NONCLUSTERED INDEX [IX_Reporting_ReportTable_TableReportID_TableName] ON [dbo].[Reporting_ReportTable]
(
	[TableName] ASC,
	[TableReportID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
ALTER TABLE [dbo].[Reporting_ReportTable]  WITH CHECK ADD  CONSTRAINT [FK_Reporting_ReportTable_TableReportID_Reporting_Report] FOREIGN KEY([TableReportID])
REFERENCES [dbo].[Reporting_Report] ([ReportID])
GO
ALTER TABLE [dbo].[Reporting_ReportTable] CHECK CONSTRAINT [FK_Reporting_ReportTable_TableReportID_Reporting_Report]
GO
