SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [Proc_CMS_PageUrlPath_ChangeUrlCultureFormat]
	@SiteID INT,
	@CultureCode NVARCHAR(50) = NULL,
	@AddCulturePrefix BIT,
	@DefaultCultureCode NVARCHAR(50),
	@HidePrefixForDefaultCulture BIT
AS
BEGIN
    BEGIN TRANSACTION
		BEGIN TRY
			UPDATE [CMS_PageUrlPath]
			SET [PageUrlPathUrlPath] = 
					CASE WHEN @CultureCode IS NULL AND [PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
					THEN [PageUrlPathUrlPath] 
					ELSE 
						CASE @AddCulturePrefix 
						WHEN 1 THEN 
							[PageUrlPathCulture] + '/' + [PageUrlPathUrlPath]
						ELSE 
							SUBSTRING([PageUrlPathUrlPath], LEN([PageUrlPathCulture]) + 2, LEN([PageUrlPathUrlPath]))
						END
					END,
				[PageUrlPathUrlPathHash] = 
					CASE WHEN @CultureCode IS NULL AND [PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
					THEN CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER([PageUrlPathUrlPath])), 2)
					ELSE 
						CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(CASE @AddCulturePrefix WHEN 1 THEN [PageUrlPathCulture] + '/' + [PageUrlPathUrlPath] ELSE SUBSTRING([PageUrlPathUrlPath], LEN([PageUrlPathCulture]) + 2, LEN([PageUrlPathUrlPath])) END)), 2)
					END
			WHERE [PageUrlPathSiteID] = @SiteID AND (@CultureCode IS NULL OR [PageUrlPathCulture] = @CultureCode)
		END TRY
		BEGIN CATCH
			IF XACT_STATE() = 1
			BEGIN
				DECLARE @CollisionPaths TABLE(
					[PathID] INT NOT NULL, 
					[NewPath] NVARCHAR(2000) NOT NULL,
					[OldPath] NVARCHAR(2000) NOT NULL,
					[Culture] NVARCHAR(50) NOT NULL)
				
				DECLARE @AltUrl TABLE(
					[AlternativeUrl] NVARCHAR(450) NOT NULL
				)

				INSERT INTO @AltUrl
					SELECT [AlternativeUrlUrl]				
					FROM [CMS_AlternativeUrl] [A1]
					WHERE NOT EXISTS 
						(SELECT 1 FROM [CMS_AlternativeUrl] [A2] 
							WHERE [A1].[AlternativeUrlUrl] LIKE [A2].[AlternativeUrlUrl] + '/%' 
								AND [A1].[AlternativeUrlSiteID] = [A2].[AlternativeUrlSiteID])
						AND [A1].[AlternativeUrlSiteID] = @SiteID;

				INSERT INTO @CollisionPaths 
					SELECT 
						[PageUrlPathID] AS [PathID], 
						[PageUrlPathUrlPath] + '-' + LOWER(CONVERT(VARCHAR(32), HASHBYTES('MD5', LOWER([PageUrlPathUrlPath] + [PageUrlPathCulture] + CONVERT(NVARCHAR(36), [NodeGUID]))), 2)) AS [NewPath],
						[PageUrlPathUrlPath] AS [OldPath],
						[PageUrlPathCulture] AS [Culture]
					FROM [CMS_PageUrlPath] [P]
					INNER JOIN [CMS_Tree] ON [NodeID] = [PageUrlPathNodeID]
					INNER JOIN @AltUrl [A] ON [A].[AlternativeUrl] = 
						CASE WHEN @CultureCode IS NULL AND [P].[PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
						THEN [P].[PageUrlPathUrlPath] 
						ELSE 
							CASE @AddCulturePrefix 
							WHEN 1 THEN 
								[P].[PageUrlPathCulture] + '/' + [P].[PageUrlPathUrlPath]
							ELSE 
								SUBSTRING([P].[PageUrlPathUrlPath], LEN([P].[PageUrlPathCulture]) + 2, LEN([P].[PageUrlPathUrlPath]))
							END
						END
					WHERE [PageUrlPathSiteID] = @SiteID AND (@CultureCode IS NULL OR [PageUrlPathCulture] = @CultureCode)

				INSERT INTO @CollisionPaths
					SELECT
						[P].[PageUrlPathID] AS [PathID], 
						[C].[NewPath] + SUBSTRING([P].[PageUrlPathUrlPath], LEN([C].[OldPath]) + 1, LEN([P].[PageUrlPathUrlPath])) AS [NewPath],
						[P].[PageUrlPathUrlPath] AS [OldPath],
						[P].[PageUrlPathCulture] AS [Culture]
					FROM @CollisionPaths [C]
					INNER JOIN [CMS_PageUrlPath] [P] ON [P].[PageUrlPathUrlPath] LIKE [C].[OldPath] + '/%'
					WHERE [P].[PageUrlPathSiteID] = @SiteID  AND (@CultureCode IS NULL OR [P].[PageUrlPathCulture] = @CultureCode) AND [C].[Culture] = [P].[PageUrlPathCulture]
								
				UPDATE [P]
				SET [P].[PageUrlPathUrlPath] = 
						CASE WHEN @CultureCode IS NULL AND [P].[PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
						THEN COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]) 
						ELSE 
							CASE @AddCulturePrefix 
							WHEN 1 THEN 
								[P].[PageUrlPathCulture] + '/' + COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])
							ELSE 
								SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]), LEN([P].[PageUrlPathCulture]) + 2, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])))
							END
						END,
					[P].[PageUrlPathUrlPathHash] = 
						CASE WHEN @CultureCode IS NULL AND [P].[PageUrlPathCulture] = @DefaultCultureCode AND @HidePrefixForDefaultCulture = 1 
						THEN CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]))), 2) 
						ELSE 
							CONVERT(VARCHAR(64), HASHBYTES('SHA2_256', LOWER(CASE @AddCulturePrefix WHEN 1 THEN [P].[PageUrlPathCulture] + '/' + COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]) ELSE	SUBSTRING(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath]), LEN([P].[PageUrlPathCulture]) + 2, LEN(COALESCE([C].[NewPath], [P].[PageUrlPathUrlPath])))	END)), 2)
						END
				FROM [CMS_PageUrlPath] [P]
				LEFT JOIN @CollisionPaths [C] ON [P].[PageUrlPathID] = [C].[PathID]
				WHERE [P].[PageUrlPathSiteID] = @SiteID AND (@CultureCode IS NULL OR [P].[PageUrlPathCulture] = @CultureCode)
			END
			ELSE
			BEGIN
				ROLLBACK TRANSACTION	
			END
		END CATCH	
	COMMIT TRANSACTION
END
GO
