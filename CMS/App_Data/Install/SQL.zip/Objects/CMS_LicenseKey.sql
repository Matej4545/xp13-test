SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[CMS_LicenseKey](
	[LicenseKeyID] [int] IDENTITY(1,1) NOT NULL,
	[LicenseDomain] [nvarchar](255) NULL,
	[LicenseKey] [nvarchar](max) NULL,
	[LicenseEdition] [nvarchar](200) NULL,
	[LicenseExpiration] [nvarchar](200) NULL,
	[LicenseServers] [int] NULL,
 CONSTRAINT [PK_CMS_LicenseKey] PRIMARY KEY NONCLUSTERED 
(
	[LicenseKeyID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
SET ANSI_PADDING ON
GO
CREATE CLUSTERED INDEX [IX_CMS_LicenseKey_LicenseDomain] ON [dbo].[CMS_LicenseKey]
(
	[LicenseDomain] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
GO
