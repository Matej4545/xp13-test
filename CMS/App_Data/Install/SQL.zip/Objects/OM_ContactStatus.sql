SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OM_ContactStatus](
	[ContactStatusID] [int] IDENTITY(1,1) NOT NULL,
	[ContactStatusName] [nvarchar](200) NOT NULL,
	[ContactStatusDisplayName] [nvarchar](200) NOT NULL,
	[ContactStatusDescription] [nvarchar](max) NULL,
 CONSTRAINT [PK_OM_ContactStatus] PRIMARY KEY CLUSTERED 
(
	[ContactStatusID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON)
)
GO
ALTER TABLE [dbo].[OM_ContactStatus] ADD  CONSTRAINT [DEFAULT_OM_ContactStatus_ContactStatusName]  DEFAULT ('') FOR [ContactStatusName]
GO
ALTER TABLE [dbo].[OM_ContactStatus] ADD  CONSTRAINT [DEFAULT_OM_ContactStatus_ContactStatusDisplayName]  DEFAULT ('') FOR [ContactStatusDisplayName]
GO
